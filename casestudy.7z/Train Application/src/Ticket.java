package casestudy1;


import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;


public class Ticket {

	static int counter =100;
	String pnr;
	LocalDate travelDate;
	Train train;

	Map<Passenger, Double > passengers = new TreeMap<>();
	Ticket(){};


	public Ticket(LocalDate travelDate, Train train) {
		super();
		this.travelDate = travelDate;
		this.train = train;
	}

	public static int getCounter() {
		return counter;
	}


	public static void setCounter(int counter) {
		Ticket.counter = counter;
	}


	public String getPnr() {
		return pnr;
	}


	public void setPnr(String pnr) {
		this.pnr = pnr;
	}


	public LocalDate getTravelDate() {
		return travelDate;
	}


	public void setTravelDate(LocalDate travelDate) {
		this.travelDate = travelDate;
	}


	public Train getTrain() {
		return train;
	}


	public void setTrain(Train train) {
		this.train = train;
	}


	public Map<Passenger, Double> getPassengers() {
		return passengers;
	}

	public void setPassengers(Map<Passenger, Double> passengers) {
		this.passengers = passengers;
	}

	public String generatePNR() {

		String newstring = travelDate.format(DateTimeFormatter.ofPattern("YYYYMMDD"));
		pnr = train.getSource().charAt(0)+ "" +train.getDestination().charAt(0)+ "" + newstring+ "_"+ counter;
		return pnr;
	}


	public double calcPassengerFare(Passenger p1) {

		if (p1.getAge() <= 12)
			return (train.getTicketPrice()*0.5);
		else if(p1.getAge() >= 60) 
			return (train.getTicketPrice()*0.6);		
		else if (p1.getGender() == 'F') 
			return (train.getTicketPrice()*0.75);
		else return (train.getTicketPrice());
	}


	public void addPassenger(String name, int age, char gender) {

		Passenger p1 = new Passenger();
		p1.setName(name);
		p1.setAge(age);
		p1.setGender(gender);
		passengers.put(p1, calcPassengerFare(p1));		
	}


	public double totalTicketPrice() {
		return passengers.entrySet().stream().mapToDouble(Map.Entry::getValue).sum();
	}

	public StringBuilder generateTicket() {

		String gfg2 = "PNR\t" + this.generatePNR() + "\n" +
				"Train number\t" + train.getTrainno()+ "\n"+
				"Train Name\t" + train.getTrainname() + "\n"+
				"From\t"+ train.getSource()+ "\n" +
				"To\t" + train.getDestination()+ "\n"+
				"TravelDate\t"+ "21-8-21" + "\n"+
				"Passengers: " + "\n"+
				"Name\t" +"Age\t" +"Gender\t"+"Fare\t"+"\n";

		StringBuilder str = new StringBuilder(gfg2);
		for(Map.Entry<Passenger, Double>entry : passengers.entrySet()) {

			Passenger p1 = entry.getKey();
			str.append(p1.getName()+"\t"+p1.getAge()+ "\t"+ p1.getGender()+"\t"+entry.getValue());
		}
		str.append("Total price:" +this.totalTicketPrice()+ "\n\n");
		System.out.println(str);
		return str;
	}
	
	public void writeTicket() {

		FileWriter fWriter;
		try {
			fWriter = new FileWriter("D:\\" +this.generatePNR()+".txt",true);
			fWriter.write(this.generateTicket().toString());
			fWriter.close();
		}catch (IOException e) {
			System.out.println("Exception occured");
			e.printStackTrace();
		}
	}
}